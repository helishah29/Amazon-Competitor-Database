-- Creating a database named AmazonCompetitor
Create Database AmazonCompetitor;
Go

-- Use Database UberCompetitor
Use AmazonCompetitor;
Go