-- Inserting into all other tables now
USE AmazonCompetitor;

SELECT * FROM Address;
SELECT * FROM CardDetails;
SELECT * FROM Invoice;
SELECT * FROM Orders;
SELECT * FROM WishList;
SELECT * FROM WishListMapping;
SELECT * FROM ProductSuggestions;
SELECT * FROM Shipping;
SELECT * FROM ProductOrder;
SELECT * FROM Review;
SELECT * FROM Suppliers;
SELECT * FROM ProductSupplier;
SELECT * FROM Warehouse;
SELECT * FROM WarehouseProduct;
SELECT * FROM ShippingWarehouse;













-- Insert Into Warehouse values
-- ('1','425 Greenwood Place','Syracuse','New York', '13210'),
-- ('2','425 California Place','New York','New York', '67482'),
-- ('3','425 Argan Place','Edison','New Jersey', '66574'),
-- ('4','425 Herbal Place','Chicago','Illinois', '76843'),
-- ('5','425 LaFeyyete Place','Tampa','Florida', '26468'),
-- ('6','425 Westcott Place','Orlando','Florida', '54839'),
-- ('7','425 Applewood Place','San Fransisco','California', '76869'),
-- ('8','425 Chicago Place','Miami','Florida', '46758'),
-- ('9','425 East Place','New York','New York', '76845'),
-- ('10','425 West Place','Albany','New York', '56382');



-- Insert Into ShippingWarehouse values
-- ('1','5','1'),
-- ('2','2','4'),
-- ('3','5','2'),
-- ('4','7','6'),
-- ('5','4','3'),
-- ('6','3','4'),
-- ('7','2','5'),
-- ('8','4','3'),
-- ('9','1','5'),
-- ('10','9','7');
