USE AmazonCompetitor;
GO

EXEC BigWishList;