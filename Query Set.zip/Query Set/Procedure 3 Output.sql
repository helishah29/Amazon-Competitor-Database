USE AmazonCompetitor;
GO

EXEC CustomerAddress 'New York';

-- for checking the correctness of output:
SELECT * FROM Address;