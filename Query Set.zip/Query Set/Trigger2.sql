USE AmazonCompetitor;
GO
-- Observing the result of Trigger on INSERT of Orders
INSERT INTO Orders values ('11', '7', 'Complete', '350', '11/12/2019', '12/1/2019', '10');