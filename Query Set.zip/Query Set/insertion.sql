USE AmazonCompetitor;

Insert Into Customers values
('1','Carlos','Leal','cgleal','crlgleal','csg@gmail.com','5683959285'),
('2','Heli','Shah','hpshah','crlgleal','hps@gmail.com','4532425436'),
('3','Hetal','Bhatia','htshah','bfdgbdfsd','hbha@gmail.com','5689864575'),
('4','Ishi','Shah','ishah','cbfle','ishh@gmail.com','8753959285'),
('5','Robert','Harris','rbhar','dsfbbf','robbb@gmail.com','9883959285'),
('6','Michael','Singhal','mikeg','vfbfdb','mikeg@gmail.com','3453959285'),
('7','Aabhas','Perez','aasing','bfbfd','aabhp@gmail.com','0796959285'),
('8','John','Shah','jshah','bdfb','jshah@gmail.com','8645395925'),
('9','Paresh','Patel','ppatel','bfbfbd','ppat@gmail.com','5463959285'),
('10','Rajan','Shah','rshah','nhgnh','shahr@gmail.com','5689509437');

SELECT * FROM Customers;

Insert Into Products values
('1','Shampoo','HairWash','house','25'),
('2','Tomato','Vegetables','grocery','2'),
('3','Tshirt','Clothing upper','apparel','56'),
('4','Shoes','Feet wear','apparel','98'),
('5','Belt','accessories','accessory','30'),
('6','Conditioner','HairWash','house','20'),
('7','Tissue','Cleaning','house','5'),
('8','Paper','Writing','stationery','1'),
('9','Pen','Writing','stationry','4'),
('10','Paracetamol','Medical','mdicine','9');

SELECT * FROM Products;